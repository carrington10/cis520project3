#ifndef TESTS_VM_QSORT_H
#define TESTS_VM_QSORT_H 1

#include <stddef.h>

void qsort_bytes (unsigned char *buf, size_t size);

#endif /* tests/vm/qsort.h */
